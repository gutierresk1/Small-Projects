/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment.pkg5;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import cards.Deck;
import cards.Hand;
import cards.Card;
import cards.Suit;
import cards.Rank;
import java.util.ArrayList;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.image.Image;



/**
 * FXML Controller class
 *
 * @author gutierresk1
 */
public class Assignment5FXMLController implements Initializable {
// 
    @FXML
    private Label label;
    @FXML
    private Pane Pane1;
    @FXML
    private Button btnShuffle;
    @FXML
    private Button btnDealCard;
    @FXML
    private Pane Pane2;
    @FXML
    private ChoiceBox<String> ChoiceBox;
    @FXML
    private Button btnCount;
    @FXML
    private Label lblSuit;
    @FXML
    private Label lblAnnoucement;
    @FXML
    private Label lbl1;
    @FXML
    private Label lblControl;
    @FXML
    private Button btnexit;
    @FXML
    private ImageView imgCard0;
    @FXML
    private ImageView imgCard1;
    @FXML
    private ImageView imgCard2;
    @FXML
    private ImageView imgCard3;
    @FXML
    private ImageView imgCard4;
    @FXML
    private ImageView imgCard5;
    @FXML
    private ImageView imgCard6;
    @FXML
    private ImageView imgCard7;
    @FXML
    private Label suitCounter;
    @FXML
    private Label lblDetermine;
// Instantiation 
    Card newCard; 
    Deck newDeck; 
    //So this is a global variable, it will be used in the handleButtonActionDealCard.
    int totalCounter; 
    int index; 
    Alert alert;
    ArrayList <Card> suitList; 
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // This code is to hide pane. 
        Pane2.setVisible(false);
        newCard = new Card(); 
        newDeck = new Deck();
        //  This is to initialize objects
        index = 0; 
        totalCounter = 0;
        newDeck.shuffle();
        ChoiceBox.getItems().addAll("clubs","diamonds","hearts","spades");
        ChoiceBox.setValue("clubs");
        suitList = new ArrayList<>();
    }    

    @FXML
    private void handleButtonActionShuffle(ActionEvent event) {
        newDeck.restart();
    // Show the alert box " Game Reset"     
        alert.setContentText("Game Reset");
        alert.showAndWait();
    // This code is to restart everything.     
        imgCard0.setImage(null);
        imgCard1.setImage(null);
        imgCard2.setImage(null);
        imgCard3.setImage(null);
        imgCard4.setImage(null);
        imgCard5.setImage(null);
        imgCard6.setImage(null);
        imgCard7.setImage(null);
    // Enable buttons.    
        btnDealCard.setDisable(false);
    // To hide pane, again... 
        Pane2.setVisible(false);
        totalCounter = 0; 
    // Clear out label and set the choice box to the original "clubs"    
        suitCounter.setText("");
        ChoiceBox.setValue("clubs");
    }

    @FXML
    private void handleButtonActionDealCard(ActionEvent event) {
        alert = new Alert(AlertType.INFORMATION);
        alert.setTitle("Information Dialog");
        alert.setHeaderText(null);
        // Now this start to get complicated. First, I created a local object. 
        Card selectedCard = newDeck.deal();
        int counter = selectedCard.getBlackJackValue(); 
        // This code return string method inside the card class that give you the file path 
        String filename= selectedCard.getImageFileName();
        Image image = new Image("cards/"+filename, true);
        // It is equivalent to the sum. 
                if(totalCounter <= 17){ 
                    /**
                     The isEmpty function/method comes from below. 
                     * Each time we deal a card. It goes into the Card Object I created. 
                     * inside of this if statement, i check if the value of the card, set to Black Jack, is <= 17. 
                     * if it is, we go inside of the condition, and check if the imageview is used or not. 
                     * if it is, we continue to the next imageview. 
                     * when the condition is met, I send an alert to the player, displaying their suit, rank, and image filename.
                     **/
                   
                    if(isEmpty(imgCard0)){
                    imgCard0.setImage(image);
                    totalCounter += counter;
                    alert.setContentText("Dealt "+ selectedCard.getRank().toString()+ " of "+ selectedCard.getSuit().toString()
                    + "(image "+filename+")" + "Sum of hand "+ totalCounter);
                    alert.showAndWait();
                    }
                    else if(isEmpty(imgCard1)){
                    imgCard1.setImage(image);
                    totalCounter += counter; 
                    alert.setContentText("Dealt "+ selectedCard.getRank().toString()+ " of "+ selectedCard.getSuit().toString()
                    + "(image "+filename+")" + "Sum of hand "+ totalCounter);
                    alert.showAndWait();
                    }
                    else if(isEmpty(imgCard2)){
                    imgCard2.setImage(image);
                    totalCounter += counter;
                    alert.setContentText("Dealt "+ selectedCard.getRank().toString()+ " of "+ selectedCard.getSuit().toString()
                    + "(image "+filename+")" + "Sum of hand "+ totalCounter);
                    alert.showAndWait();
                    }
                    else if(isEmpty(imgCard3)){
                    imgCard3.setImage(image);
                    totalCounter += counter;
                    alert.setContentText("Dealt "+ selectedCard.getRank().toString()+ " of "+ selectedCard.getSuit().toString()
                    + "(image "+filename+")" + "Sum of hand "+ totalCounter);
                    alert.showAndWait();
                    }
                    else if(isEmpty(imgCard4)){
                    imgCard4.setImage(image);
                    totalCounter += counter;
                    alert.setContentText("Dealt "+ selectedCard.getRank().toString()+ " of "+ selectedCard.getSuit().toString()
                    + "(image "+filename+")" + "Sum of hand "+ totalCounter);
                    alert.showAndWait();
                    }
                    else if(isEmpty(imgCard5)){
                    imgCard5.setImage(image);
                    totalCounter += counter;
                    alert.setContentText("Dealt "+ selectedCard.getRank().toString()+ " of "+ selectedCard.getSuit().toString()
                    + "(image "+filename+")" + "Sum of hand "+ totalCounter);
                    alert.showAndWait();
                    }
                    else if(isEmpty(imgCard6)){
                    imgCard6.setImage(image);
                    totalCounter += counter;
                    alert.setContentText("Dealt "+ selectedCard.getRank().toString()+ " of "+ selectedCard.getSuit().toString()
                    + "(image "+filename+")" + "Sum of hand "+ totalCounter);
                    alert.showAndWait();
                    }
                    else if(isEmpty(imgCard7)){
                    imgCard7.setImage(image);
                    totalCounter += counter;
                    alert.setContentText("Dealt "+ selectedCard.getRank().toString()+ " of "+ selectedCard.getSuit().toString()
                    + "(image "+filename+")" + "Sum of hand "+ totalCounter);
                    alert.showAndWait();
                    }
                }
                //This if code statement show player if they won or not, depending if they get somewhere between 17 and 21
                if(totalCounter >=17 && totalCounter<=21){
                    btnDealCard.setDisable(true);
                    Pane2.setVisible(true);
                    lblDetermine.setText("Congratulations! You Win!!");
                //It is very hard to lose, but here is how it may happens...
                }else if (totalCounter >21){
                    btnDealCard.setDisable(true);
                    Pane2.setVisible(true);
                    lblDetermine.setText("Better Luck Next Time...;-;");
                }
        suitList.add(selectedCard);
        //For every card selected that has met conditions, I put in a Card ArrayList.
    }

    @FXML
    private void handleButtonActionChoiceBox(MouseEvent event) {
          
    }

    @FXML
    private void handleButtonActionCount(ActionEvent event) {
        //Function when player clicks "count" button. 
        String userChoice = ChoiceBox.getValue();
        //Choicebox has string values. The one showing is the one selected.
        int counter = 0; 
        //a counter to keep track of how many suits we have.
        for(int i =0; i<suitList.size(); i++){
            //This code is a for loop that repeats until the end of the suitlist size. 
            
            //The code checks if the current iteration of the Card Suit is == the one the player has chosen
            if(suitList.get(i).getSuit().toString()==userChoice){
                counter++;
                //if true, the counter goes up!
            }
        String newString = userChoice.substring(0, userChoice.length()-1);
        //I created a substring to format the label better
        suitCounter.setText(counter + " "+newString+ "(s) in hand");
        //The code displays the final result
       } 
    }

    @FXML
    private void handleButtonActionExit(ActionEvent event) {
        //This code exit the game. 
        System.exit(0);
    }
    // I was really stuck. I got help from google for this part. I hope you don't mind
    public static boolean isEmpty(ImageView imageView) {
    //This function verified if imageView is empty (null)
    Image image = imageView.getImage();
    return image == null || image.isError();
    }
}
