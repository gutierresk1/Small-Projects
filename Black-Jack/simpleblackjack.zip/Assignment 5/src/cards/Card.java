/*
 * Card.java - represents a playing card.
 * Depends on having Rank and Suit enumerated types.
 *
 * Last updated 02/19/2016 - added function to get file name for the cards
 *       and function to report if the card is illegal
 * Created on February 5, 2008, 9:50 PM
 * Created on March 3, 2005, 9:32 AM
 * Originally Created on February 17, 2005, 9:05 AM
 *
 * Author: Dr. Michael Redmond, redmond@lasalle.edu
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package cards;

/**
 *
 * @author Mike Redmond - redmond@lasalle.edu
 */
public class Card implements Comparable {


    //////////////////////////////////
    /// instance variables
    //////////////////////////////////
    private Suit suit;
    private Rank rank;



    //////////////////////////////////
    /// constructors
    //////////////////////////////////

    /** 
     * Creates a default new instance of Card - the ace of spades
     */
    public Card() {
        suit = Suit.spades;
        rank = Rank.ace;
    }
    
    /**
     * creates a new instance of Card, given a Suit and a Rank
     */
    public Card (Suit s, Rank r ) {
        suit = s;
        rank = r;
    }


    //////////////////////////////////
    /// accessors / inspectors / getters
    //////////////////////////////////

    /**
     * report a card's Suit
     */
    public Suit getSuit () {
        return suit;
    }
    
    /**
     * report a cards Rank
     */
    public Rank getRank() {
        return rank;
    }


    //////////////////////////////////
    /// pseudo-inspectors
    //////////////////////////////////


    /**
     * reports point value of the card for Bridge (ignoring "distribution points"
     * e.g. having no card in a particular suit)
     */
    public int getBridgeValue() {
        int res = 0;
        Rank curr = this.getRank();
        // Aces are 4 points, Kings are 3, Queens are 2, Jacks are 1,
        // everything else is zero
        if (curr == Rank.ace) {
            res = 4;
        }
        else if (curr == Rank.king){
            res = 3;
        }
        else if (curr == Rank.queen) {
            res = 2;
        }
        else if (curr == Rank.jack) {
            res = 1;
        }
        return res;
    }

    /**
     * reports point value of the card for Blackjack (ignoring the flexibility for Aces)
     */
    public int getBlackJackValue() {
        int res = 10;
        Rank curr = this.getRank();
        // Aces are 11 points, face cards 10, all others their own value
        if (curr == Rank.ace) {
            res = 11;
        }
        else if ((curr == Rank.king) || (curr == Rank.queen) || (curr == Rank.jack) || (curr == Rank.ten)){
            res = 10;
        }
        else if (curr == Rank.nine) {
            res = 9;
        }
        else if (curr == Rank.eight) {
            res = 8;
        }
        else if (curr == Rank.seven) {
            res = 7;
        }
        else if (curr == Rank.six) {
            res = 6;
        }
        else if (curr == Rank.five) {
            res = 5;
        }
        else if (curr == Rank.four) {
            res = 4;
        }
        else if (curr == Rank.three) {
            res = 3;
        }
        else if (curr == Rank.two) {
            res = 2;
        }
        else {
            // should never be able to hit this code
            res = -1;
        }
        return res;
    }

    /**
     * reports point value of the card for Hearts (ignoring "shoot the moon"
     * e.g. winning all of the point cards )
     */
    public int getHeartsValue() {
        int res = 0;
        Suit currSuit = this.getSuit();
        Rank curr = this.getRank();
        if (currSuit == Suit.hearts) {
            res = 1;
        }
        // queen of spades is 13
        else if ((currSuit == Suit.spades) && (curr == Rank.queen)) {
            res = 13;
        }
        return res;
    }


    /**
     * Reports the filename of the image corresponding to the card.
     */
    public String getImageFileName () {
//        // first test - build one in 
//        String image = "CARDS4.gif";
        /// card #s start with 1 with the ace of clubs, other aces, then two of clubs, other twos, etc
        int rankPart = 0;
        // ace is lowest but enumerated type has it as the largest, so handle it specially
        if (this.rank == Rank.ace) {
            rankPart = 0;
        }
        else {
            // twos are ordinal 1, so add one to make it two
            rankPart = this.rank.ordinal() + 1;
        }
        // suits in enumerated type are in opposite order from the card#s
        int suitPart = 4 - this.suit.ordinal();
        // make room for all 4 of a rank - aces are going to be 1-4, twos 5-8
        int number = rankPart * 4 + suitPart;
        String image = "CARDS" + number + ".gif";
        return image;
    }

    //////////////////////////////////
    /// mutators / setters
    //////////////////////////////////

    /**
     * change a card's suit
     */
    public void setSuit (Suit s) {
        suit = s;
    }
    
    /**
     * change a card's rank
     */
    public void setRank (Rank r) {
        rank = r;
    }


    //////////////////////////////////
    /// controlled mutators
    //////////////////////////////////

    /**
     * reports whether two cards have equal contents
     */
    public boolean equals (Object obj) {
        if (!(obj instanceof Card)) {
            // can't be equal if not the same typ object
            return false;
        }
        else {
            Card toCompare = (Card) obj;
            // if all data equal then objects equal
            if ((suit.equals(toCompare.getSuit()))
                && (rank == toCompare.getRank()) ) {  
                    return true;
            }
            else {
                return false;
            }
        }
    }



    //////////////////////////////////
    ///override Object versions
    //////////////////////////////////

    /**
     * produces a string representation of a card
     */
    public String toString() {
        String res = "";
        res = res + rank.toString() + " of ";
        res = res + suit.toString();
        return res;

        
    }



    //////////////////////////////////
    /// for Comparable
    //////////////////////////////////

    /** Compares two Cards - needed for sorting - required since implements Comparable interface
     * returns negative if passed object comparing to is greater, zero if object comparing to is equal,
     * positive if passed object comparing to is less
     */
    public int compareTo (Object obj) {        
    // convert the passed object into an Card - really should check that this isn't going to crash
        Card other = (Card) obj;
        // pull out the ranks to compare
        Rank otherRank = other.getRank();
        Rank firstRank = getRank();
        /*
        if (firstRank < otherRank) {
            return -1;
        }
        else if (firstRank > otherRank) {
            return 1;
        }
        else {
            return 0;
        }
         **/
        return firstRank.compareTo(otherRank);
    }
    


    //////////////////////////////////
    /// other - specialized methods
    //////////////////////////////////
    
    /**
     * report if the card is illegal - if either the rank or suit is illegal
     * @return 
     */
    public boolean isIllegal() {
        if ((this.rank == Rank.illegal) || (this.suit == Suit.illegal) ) {
            return true;
        }
        else {
            return false;
        }
    }

}
