/*
 * Hand.java - handle a hand of cards.
 * Last Update: 02/19/2016 - added getNthCard
 *     also adjusted playSuitChoiceNotCarefulAndReplace so that if the play was not successful, it does not draw a new card
 * ArrayList version - used for 2009 Midterm #2
 * Depends on Card and Deck classes.
 * Created 04/07/2009 based on Hand class with history:
 *      Created on March 3, 2005, 9:36 AM
 *      Originally Created on February 17, 2005, 11:53 AM
 *
 * Author: Dr. Michael Redmond, redmond@lasalle.edu
 */

package cards;

import java.util.ArrayList;
import javax.swing.JOptionPane;



/**
 *
 * @author Mike Redmond - redmond@lasalle.edu
 */
public class Hand {



    //////////////////////////////////
    /// instance variables
    //////////////////////////////////
    ArrayList cards = new ArrayList();
//    int numInHand;   // not needed since now using ArrayList instead of array


    //////////////////////////////////
    /// constructors
    //////////////////////////////////

    /** Creates a new instance of Hand, initially empty */
    public Hand() {
//        numInHand = 0;
        cards = new ArrayList();
    }
    
    /** Creates a new instance of Hand with
     *   known size but cards not dealt yet.
     * Probably not needed for ArrayList version
     */
    public Hand(int siz) {
//        numInHand = 0;
        cards = new ArrayList(siz);
    }
    
    
    /** Creates a new instance of Hand with
     *   known size and deal cards from a passed deck.
     *   If the deck runs out, this will put illegal cards in the hand. No problem for now!
     */
    public Hand(int siz, Deck toDrawFrom) {
        int numInHand = 0;
        cards = new ArrayList();
        for (numInHand = 0; numInHand < siz; numInHand++) {
                cards.add(toDrawFrom.deal());
        }
    }


    //////////////////////////////////
    /// inspectors / accessors / getters
    //////////////////////////////////

    /** 
     * report how many cards are in the hand
     */
    public int getNumInHand () {
        return cards.size();
    }
    
    
    /**
     * Report the nth card in the hand (starts counting from zero). If that many don't exist, returns an illegal card.
     */
    public Card getNthCard(int n) {
        Card toReturn = new Card(Suit.illegal, Rank.illegal);
        // has to be less because if there are 5 cards they are 0-4
        if (n < this.getNumInHand()) {
            toReturn = (Card)this.cards.get(n);
        
        }
        return toReturn;
    }




    //////////////////////////////////
    /// mutators /  setters
    //////////////////////////////////



    //////////////////////////////////
    /// controlled mutators
    //////////////////////////////////

    /**
     * add a given card to the hand. Easy with ArrayLists
     */
    public boolean addToHand (Card toAdd) {
        cards.add(toAdd);
        return true; // always works so far
    }


    /**
     * Play the 0th card in the hand (starts counting from 0).
     * For now, if hand is empty, returns an illegal card.
     * Remove the chosen card from the hand and return the card.
     */
    public Card playFirst () {
        Card res = this.playChoice(0);
        return res;
    }


    /**
     * Play the 0th card in the hand (starts counting from 0).
     * For now, if hand is empty, returns an illegal card.
     * Remove the chosen card from the hand and return the card.
     * Replace the card by drawing from the passed deck.
     * For now, if the deck is empty, we will get an illegal Card.
     * Later we will use exceptions.
     */
    public Card playFirstAndReplace (Deck toDrawFrom) {
        Card res = this.playChoiceAndReplace(0, toDrawFrom);
        return res;
    }

    /**
     * Play the nth card in the hand (n starts counting from 0).
     * For now, if actual parameter is too high, return an illegal card.
     * Remove the chosen card from the hand and return the card.
     */
    public Card playChoice (int choice) {
        if (choice >= cards.size()) {
            return new Card(Suit.illegal,Rank.illegal);
        }
        // we're ok - get the card, remove it from the Hand and moves others up
        Card res = (Card) cards.remove(choice);
//        numInHand--;
        return res;
    }
    
    
    /**
     * Play the nth card in the hand (n starts counting from 0).
     * For now, if actual parameter is too high, return an illegal card.
     * Remove the chosen card from the hand and return the card.
     * Replace the card by drawing from the passed deck.
     * For now, if the deck is empty, just let it go without replacement.
     * Later we will use exceptions.
     */
    public Card playChoiceAndReplace (int choice, Deck toDrawFrom) {
        if (choice >= cards.size()) {
            return new Card(Suit.illegal,Rank.illegal);
        }
        // we're ok - get the card, remove it from the Hand and moves others up
        Card res = (Card) cards.remove(choice);
        try {
            Card replacement = toDrawFrom.dealRobust();
            cards.add(replacement);
        }
        catch (DeckEmptyException ex) {
            // no replacement available -
//            return new Card(Suit.illegal,Rank.illegal);
            return res;
        }
        return res;
    }

    
    // ####################### 2
    
    /**
     * return a card from the hand given a specific suit.
     * Remove the chosen card from the hand and return the card.
     * Removes the last correct suit card in the hand.
     * for now, if one isn't found, returns an illegal card.
     */
    public Card playSuitChoiceNotCareful (Suit toPlay) {
        Card choice = new Card(Suit.illegal,Rank.illegal);
        for (Object current : cards) {
            Card curr = (Card) current;
            if (curr.getSuit().equals(toPlay)) {
                choice = curr;
            }
        }
        // remove the card from the hand - no need to capture what card it is - we already have it
        cards.remove(choice);
        return choice;
    }


    /**
     * return a card from the hand given a specific suit.
     * Remove the chosen card from the hand and return the card.
     * Removes the last correct suit card in the hand.
     * for now, if one isn't found, returns an illegal card.
     * Replace the card by drawing from the passed deck.
     * For now, if the deck is empty, just let it go without replacement.
     * Later we will use exceptions.
     */
    public Card playSuitChoiceNotCarefulAndReplace (Suit toPlay, Deck toDrawFrom) {
        Card choice = new Card(Suit.illegal,Rank.illegal);
        for (Object current : cards) {
            Card curr = (Card) current;
            if (curr.getSuit().equals(toPlay)) {
                choice = curr;
            }
        }
        // choice has been made
        // remove the card from the hand - no need to capture what card it is - we already have it
        // if no card was found to remove, don't try to replace it
        if (choice.isIllegal()) {
            // questionable whetehr should put out an erroe message - caller from GUI class should do that
            JOptionPane.showMessageDialog(null,"no card of that suit to play");
        }
        else {
            cards.remove(choice);
            // try to replace the card
            try {
                Card replacement = toDrawFrom.dealRobust();
                cards.add(replacement);
            }
            catch (DeckEmptyException ex) {
                // no replacement available -
    //            return new Card(Suit.illegal,Rank.illegal);
                return choice;
            }
        }
        return choice;

    }



    //////////////////////////////////
    /// other specialized methods
    //////////////////////////////////

    /**
     * reports whether the hand includes a specific given card.
     * @param toFind
     * @return
     */
    public boolean containsCard (Card toFind) {
        for (Object current : cards) {
            Card curr = (Card) current;
            if (curr.equals(toFind)) {
                return true;
            }
        }
        return false;
    }

    


    //////////////////////////////////
    /// override Object version
    //////////////////////////////////

    /**
     * return a string representation for the hand.
     * @return
     */
    public String toString() {
        String res = "";
        for (Object current : cards) {
            Card curr = (Card) current;
            res = res + " " + curr + " ";
        }
        return res;
    }
    
    
}