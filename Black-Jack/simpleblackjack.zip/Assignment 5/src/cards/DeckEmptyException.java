/*
 * DeckEmptyException.java - thrown when the deck is empty when trying to deal from
 * it, in the robust version of deal.
 *
 * Created on February 5, 2008, 10:19 PM
 * Created on March 3, 2005, 9:40 AM
 * Originally Created on February 17, 2005, 11:58 AM

 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package cards;

/**
 *
 * @author Mike Redmond - redmond@lasalle.edu
 */
public class DeckEmptyException extends Exception  {
    
    private Deck emptyDeck;
    
    /** Creates a new instance of DeckEmptyException */
    public DeckEmptyException() {
        super("Trying to deal from deck and deck is empty");
    }
    
    /** Creates a new instance of DeckEmptyException */
    public DeckEmptyException(Deck ed) {
        super("Trying to deal from deck and deck is empty");
        emptyDeck = ed;
    }
    
    
    /** Creates a new instance of DeckEmptyException */
    public DeckEmptyException(Deck ed, String msg) {
        super(msg);
        emptyDeck = ed;
    }
    
    public Deck getEmptyDeck (){
        return emptyDeck;
    }
    
    public void setEmptyDeck (Deck ed) {
        // should we check that it is really empty?
        emptyDeck = ed;
    }
}


