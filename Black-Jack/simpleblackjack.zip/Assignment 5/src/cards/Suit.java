/*
 * Suit.java - represents the suit of a playing card - spades, hearts, etc
 *
 * Created on February 17, 2005, 9:00 AM
 */

package cards;

/**
 *
 * @author Mike Redmond - redmond@lasalle.edu
 */
public enum Suit { spades, hearts, diamonds, clubs, illegal }
