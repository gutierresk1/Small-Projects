/*
 * Deck.java - represents a deck of playing cards. Assumes a regular 52 card deck.
 * ArrayList version.
 * Depends on Card class.
 *
 * Changed from array version with history:
 *      Created on February 5, 2008, 10:14 PM
 *      Created on March 3, 2005, 9:38 AM
 *      Originally Created on February 17, 2005, 9:22 AM
 *
 * Author: Dr. Michael Redmond, redmond@lasalle.edu
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package cards;

import java.util.ArrayList;
import java.util.Random;
//import java.util.Arrays;
import java.util.Collections;
//import javax.swing.JOptionPane;

/**
 *
 * @author Mike Redmond - redmond@lasalle.edu
 */
public class Deck {

    //////////////////////////////////
    /// class (static) variables
    //////////////////////////////////
    private static Random generator = new Random();  // used for shuffling uses time as a seed

    //////////////////////////////////
    /// instance variables
    //////////////////////////////////
    // deck essentially is an ArrayList of Cards
    private ArrayList cards = new ArrayList();
    // but lets also keep a separate ArrayList of used Cards
    private ArrayList used = new ArrayList();
//    private int top;  // highest array element filled with a real card
        

    //////////////////////////////////
    /// constructors
    //////////////////////////////////

    /**
     * Creates a new instance of Deck
     *  Default constructor creates typical 52 card deck
     */
    public Deck() {
        int cnt = 0;
        for (Suit s : Suit.values()) {
            if (s != Suit.illegal) {
                for (Rank r : Rank.values()) {
                    if (r != Rank.illegal){
                        cards.add(new Card(s,r));
                        cnt++;
                    }
                }
            }
        }
//        top = 51;
    }
    
    /**
     * create a new instance of deck based on a passed array of cards.
     * CSC 280 students shouldn't be thinking about using this constructor
     * because we haven't covered arrays yet.
     */
    public Deck(Card [] toCopy) {
        int cnt = 0;
        for (Card curr : toCopy) {
            cards.add(curr);
            cnt++;
        }
//        top = toCopy.length - 1;
    }



    //////////////////////////////////
    /// inspectors / accessors / getters
    //////////////////////////////////



    //////////////////////////////////
    /// pseudo inspectors
    //////////////////////////////////

    /**
     * report if Deck is empty
     */
    public boolean isEmpty () {
        if (cards.size() == 0) {
            return true;
        }
            else {
                return false;
            } 
    }
    
    
    //////////////////////////////////
    /// mutators / setters
    //////////////////////////////////

    //////////////////////////////////
    /// controlled mutators
    //////////////////////////////////

    /** 
     * shuffle the deck
     */
    public boolean shuffle ( ) {
// old version has bug --  in the unlikely scenario that random number generator returns same value
// when called two times in a row
//        int rand1;
//        int rand2;
//        Card temp;
//        // for ArrayList, instead of swapping, just pull Random cards out and stick them
//        // at the end of the ArrayList
//        // twice as many times as there are cards - should be plenty shuffled
//        for (int cnt = 0; cnt < (2 * cards.size()); cnt++) {
//            rand1 = generator.nextInt(cards.size()); // generate an int from 0-largest real index
//            rand2 = generator.nextInt(cards.size()); // generate an int from 0-largest real index
//            // for debugging watch the swap
//            //System.out.println("     Swapping " + cards[rand1] + " ( " + rand1 + " )  with " + cards[rand2] + " ( " + rand2 + " )");
//
//            Card toRemove1 = (Card) cards.get(rand1);
//            Card toRemove2 = (Card) cards.get(rand2);
//            cards.remove(toRemove1);
//            cards.remove(toRemove2);
//            cards.add(toRemove1);
//            cards.add(toRemove2);
//
//       }
//        return true;  // always works for now
//    }
// new version below fixes afoementioned bug
/**
>     * shuffle the deck
>     */
         int rand1;
         int rand2;
         Card temp;
         // for ArrayList, instead of swapping, just pull Random cards out and stick them
         // at the end of the ArrayList
         // twice as many times as there are cards - should be plenty shuffled
         for (int cnt = 0; cnt < (2 * cards.size()); cnt++) {
             rand1 = generator.nextInt(cards.size()); // generate an int from 0-largest real index
             rand2 = generator.nextInt(cards.size()); // generate an int from 0-largest real index
             // for debugging watch the swap
             //System.out.println("     Swapping " + cards[rand1] + " ( " + rand1 + " )  with " + cards[rand2] + " ( " + rand2 + " )");

             Card toRemove1 = (Card) cards.get(rand1);
             cards.remove(toRemove1);
             cards.add(toRemove1);
             Card toRemove2 = (Card) cards.get(rand2);
             cards.remove(toRemove2);
             cards.add(toRemove2);
         }
         return true;  // always works for now
      }
    
    
    /** 
     * restore played cards to the deck and shuffle the deck
     */
    public boolean restart ( ) {
        // top = 51;
        // bring back played cards
        cards.addAll(this.used);
        this.shuffle();
        return true;  // always works for now
    }
    
    /**
     * deals the top card off the deck - returning the card dealt, and keeping track of change in the deck.
     * If deck is empty, return illegal Card
     * 
     */
    public Card deal () {
        if (isEmpty()) {
            // return illegal card if
            return new Card(Suit.illegal, Rank.illegal);
//            JOptionPane.showMessageDialog(null, "Out of cards in the deck. \n We need to learn exceptions. \n The program will now crash.");
        }
        // take top Card - put in used and return it
        Card res = (Card) cards.remove(0);
        used.add(res);
        return res;
    }
    
    /**
     * deals the top card off the deck - returning the card dealt, and keeping track of change in the deck.
     * If deck is empty, throws DeckEmptyException.
     * CSC 280 students - this one is NOT for you in February 2016. (requires understanding of exceptions, which we haven't covered!)
     */
    public Card dealRobust () throws DeckEmptyException {
        if (isEmpty()) {
            throw new DeckEmptyException(this);
        }
        // take top Card - put in used and return it
        Card res = (Card) cards.remove(0);
        used.add(res);
        return res;
    }


    //////////////////////////////////
    /// override Object version
    //////////////////////////////////

    /**
     * return a string representation of the deck
     * @return
     */
    public String toString () {
        String res = "";
        res = res + "Deck has " + cards.size() + "cards \n";
        for (Object current : cards) {
            Card curr = (Card) current;
            res = res + "     " + curr + "\n";
        }
        return res;
    }
    
    /** 
     *  unshuffles the deck
     */
    public void unshuffle () {
        Collections.sort(cards);
    }
    

}
