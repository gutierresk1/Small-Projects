/*
 * rank.java - represents the rank of a playing card - ace, king, queen, etc
 *
 * Created on February 17, 2005, 9:03 AM
 */

package cards;

/**
 *
 * @author Mike Redmond - redmond@lasalle.edu
 */
public enum Rank { two, three, four, five, six, seven, eight, nine, ten, jack, queen, king, ace, illegal }

